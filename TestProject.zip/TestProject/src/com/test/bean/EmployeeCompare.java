package com.test.bean;

import java.util.Comparator;
import com.test.bean.Employee;

public class EmployeeCompare implements Comparator<Employee>{
	
	

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		int result=o1.getfName().compareTo(o2.getfName());
		
		if(result > 0)
			return 1;
		else return -1;
			
		
	}


	
	
}
