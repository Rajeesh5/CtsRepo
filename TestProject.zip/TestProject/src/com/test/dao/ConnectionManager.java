package com.test.dao;

import java.sql.*;

public class ConnectionManager {

	public static Connection getConnection(){
		
		Connection connection=null;
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","rajeev","rajeev_sharma");
		}
		catch(ClassNotFoundException e){e.printStackTrace();}
		catch(SQLException e){e.printStackTrace();}
		
		return connection;
		
	}

	public static void closeConnection(Connection connection){
		
		try{
			connection.commit();
			connection.close();			
		}catch(SQLException e){e.printStackTrace();}
		
		
	}
	
}
