package com.test.main;

import com.test.bean.Employee;
import com.test.bean.EmployeeCompare;
import com.test.dao.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.Collections;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection connection=null;
		Employee emp= null;
		ArrayList<Employee> empList=new ArrayList<Employee>();
		
		
		
		try{
			connection=ConnectionManager.getConnection();
			Statement stmt=connection.createStatement();
			ResultSet rs=stmt.executeQuery("select * from Employees");  
			
			while(rs.next())  
			{
				//System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
				emp=new Employee();
				emp.setEmpId(rs.getString(1));
				emp.setfName(rs.getString(2));
				emp.setlName(rs.getString(3));
				emp.setPhNum(rs.getString(5));
				
				empList.add(emp);
				//System.out.println(emp.getEmpId()+"  "+emp.getfName()+"  "+emp.getlName()+"  "+emp.getPhNum());
			}
			
			Collections.sort(empList,new EmployeeCompare());
			
			 
			Iterator <Employee>itr=empList.iterator();
			
			  while(itr.hasNext()){
				  emp=(Employee) itr.next();
				  System.out.println(emp.getEmpId()+"  "+emp.getfName()+"  "+emp.getlName()+"  "+emp.getPhNum());
				    
			  }
			
			ConnectionManager.closeConnection(connection);
			
		}catch(SQLException e){e.printStackTrace();}
		
	
	}

}
